import './App.css'
function App() {
  return (
    <>
    <h1>Hello Jasur</h1> 
    <h2>Open new project</h2>  
    </>
  )
}
export default App
